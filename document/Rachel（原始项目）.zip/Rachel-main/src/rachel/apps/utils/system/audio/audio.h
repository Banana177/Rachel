/**
 * @file audio.h
 * @author Forairaaaaa
 * @brief
 * @version 0.1
 * @date 2023-11-18
 *
 * @copyright Copyright (c) 2023
 *
 */
#pragma once
#include "buzz_music_player/buzz_music_player.h"
