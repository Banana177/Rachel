/**
 * @file inputs.h
 * @author Forairaaaaa
 * @brief
 * @version 0.1
 * @date 2023-11-18
 *
 * @copyright Copyright (c) 2023
 *
 */
#pragma once
#include "button/button.h"
