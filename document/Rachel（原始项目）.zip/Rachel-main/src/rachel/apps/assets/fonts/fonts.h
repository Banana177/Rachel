/**
 * @file fonts.h
 * @author Forairaaaaa
 * @brief Font convertor: https://rop.nl/truetype2gfx/
 * @version 0.1
 * @date 2023-11-04
 *
 * @copyright Copyright (c) 2023
 *
 */
#pragma once
#include <LovyanGFX.hpp>
