/**
 * @file games.h
 * @author Forairaaaaa
 * @brief
 * @version 0.1
 * @date 2023-11-13
 *
 * @copyright Copyright (c) 2023
 *
 */
#pragma once

namespace ARKANOID
{
    int main(void);
}
namespace SNAKE
{
    int main(void);
}
namespace TETRIS
{
    int main(void);
}
