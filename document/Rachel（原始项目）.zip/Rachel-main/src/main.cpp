/**
 * @file main.cpp
 * @author Forairaaaaa
 * @brief
 * @version 0.1
 * @date 2023-11-07
 *
 * @copyright Copyright (c) 2023
 *
 */
#include "rachel/rachel.h"

void setup() { RACHEL::Setup(); }

void loop() { RACHEL::Loop(); }
